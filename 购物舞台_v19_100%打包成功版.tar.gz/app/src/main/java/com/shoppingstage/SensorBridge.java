package com.shoppingstage;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.webkit.JavascriptInterface;

/**
 * 传感器桥接器 - 将 Android 传感器数据传递给 JavaScript
 */
public class SensorBridge implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    
    private float lastX = 0, lastY = 0, lastZ = 0;
    private float lastRotX = 0, lastRotY = 0, lastRotZ = 0;
    
    private static final float SHAKE_THRESHOLD = 2.0f;
    private static final int SENSOR_DELAY = SensorManager.SENSOR_DELAY_GAME;
    
    public SensorBridge(Context context) {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        }
    }
    
    public void start() {
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SENSOR_DELAY);
        }
        if (gyroscope != null) {
            sensorManager.registerListener(this, gyroscope, SENSOR_DELAY);
        }
    }
    
    public void stop() {
        sensorManager.unregisterListener(this);
    }
    
    @Override
    public void onSensorChanged(SensorEvent event) {
        // 暂时不实际调用 JavaScript，避免过度调用
        // 如需启用，可以在这里调用 JavaScript 接口
    }
    
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // 不处理精度变化
    }
    
    @JavascriptInterface
    public float[] getAccelerometerData() {
        // 返回模拟数据，实际使用时应存储真实传感器数据
        return new float[]{lastX, lastY, lastZ};
    }
    
    @JavascriptInterface
    public float[] getGyroscopeData() {
        return new float[]{lastRotX, lastRotY, lastRotZ};
    }
    
    @JavascriptInterface
    public boolean hasAccelerometer() {
        return accelerometer != null;
    }
    
    @JavascriptInterface
    public boolean hasGyroscope() {
        return gyroscope != null;
    }
}