# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep SensorBridge
-keep class com.shoppingstage.SensorBridge { *; }

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep WebView related classes
-keep public class * extends android.webkit.WebChromeClient
-keep public class * extends android.webkit.WebViewClient
-keep class * extends android.webkit.WebView { public <methods>; }